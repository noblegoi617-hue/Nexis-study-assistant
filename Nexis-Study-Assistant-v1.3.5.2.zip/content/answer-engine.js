const NexisAnswerEngine = (() => {
  let lastFingerprint = "";
  let cancelled = false;

  async function process(question, onState) {
    cancelled = false;
    onState?.("EXTRACTING");
    const fingerprint = String(question.fingerprint || "");
    if (cancelled || fingerprint === lastFingerprint) return null;
    lastFingerprint = fingerprint;
    onState?.("ANALYZING");
    const result = await NexisAI.getAnswer(question);
    if (cancelled) return null;
    onState?.("ANSWER_READY");
    return { question, result };
  }
  function cancel() { cancelled = true; }
  function resetFingerprint() { lastFingerprint = ""; }
  return { process, cancel, resetFingerprint };
})();