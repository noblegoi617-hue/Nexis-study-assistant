(() => {
  if (location.hostname !== "student.atmiya.ac.in") return;
  let settings, busy = false, lastProcessed = "", completionShown = false;

  async function init() {
    settings = await NexisStorage.getAll();
    if (!settings.enabled) return;
    NexisUI.mount();
    NexisUI.setStatus("Connected to LMS", "connected");
    await NexisState.init();
    NexisPageObserver.start(schedule);
    NexisNavigation.start(() => {
      NexisAnswerEngine.resetFingerprint();
      schedule();
    });
    window.addEventListener("nexis:retry", schedule);
    schedule();
  }

  let timer;
  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(scan, 500);
  }

  async function scan() {
    if (busy || !settings?.autoDetect) return;
    if (completion()) return;
    const q = NexisDetector.detect();
    if (!q || q.text.length < 8) return;
    // Fingerprint is synchronous and always clone-safe.
    const fp = q.fingerprint;
    if (fp === lastProcessed) return;

    // Convert the detected question into a fully cloneable object before
    // passing it to the state manager or any other persistence layer.
    const safeQuestion = { ...q, fingerprint: fp };

    busy = true;
    await NexisState.update({
      status: "RUNNING",
      currentQuestion: safeQuestion,
      pendingCount: 1
    });
    NexisUI.showProcessing("EXTRACTING");
    try {
      const result = await NexisAnswerEngine.process(
        safeQuestion,
        s => NexisUI.showProcessing(s)
      );
      if (!result) return;
      lastProcessed = fp;
      const state = NexisState.get();
      await NexisState.update({
        totalProcessed: state.totalProcessed + 1,
        pendingCount: 0,
        status: "WAITING_FOR_USER"
      });
      NexisUI.showAnswer(q, result.result, settings.showConfidence);
      NexisUI.highlightCorrectOption(q, result.result);
    } catch (e) {
      const state = NexisState.get();
      await NexisState.update({ status: "ERROR", pendingCount: 0, errors: [...state.errors, String(e)] });
      NexisUI.showError(e.message || "Question processing failed.");
    } finally { busy = false; }
  }

  function completion() {
    const text = (document.body?.innerText || "").toLowerCase();
    const signals = [/session completed/, /quiz completed/, /assessment completed/, /test completed/,
      /your result/, /results are available/, /thank you.*submission/];
    const buttons = NexisDetector.findButtons();
    const finishDisabled = buttons.some(x => x.kind === "finish" && x.element.disabled);
    const yes = signals.some(r => r.test(text)) || (finishDisabled && /complete|finished|submitted/.test(text));
    if (yes && !completionShown) {
      completionShown = true;
      NexisState.update({ status: "COMPLETED", pendingCount: 0 }).then(NexisUI.showCompletion);
    }
    return yes;
  }

  init().catch(e => console.error("[NEXIS][ERROR]", e));
})();