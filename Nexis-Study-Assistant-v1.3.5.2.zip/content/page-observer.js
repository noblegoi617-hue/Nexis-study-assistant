const NexisPageObserver = (() => {
  let observer, timer;
  function start(callback) {
    stop();
    observer = new MutationObserver(() => {
      clearTimeout(timer);
      timer = setTimeout(() => callback?.(), 350);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true,
      attributeFilter: ["class","aria-label","disabled","value"] });
  }
  function stop() {
    clearTimeout(timer);
    observer?.disconnect();
    observer = null;
  }
  return { start, stop };
})();