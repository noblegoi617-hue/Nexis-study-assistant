const NexisUI = (() => {
  let root, body, header, content, minimized = false, closed = false;
  const SOCIAL = {
    guns: "https://guns.lol/knowxx001",
    instagram: "https://www.instagram.com/",
    discord: "https://discord.gg/BPUrKgthYh",
    github: "https://github.com/noblegoi617-hue/Nexis-study-assistant"
  };

  function mount() {
    if (root) return;
    root = document.createElement("section");
    root.id = "nexis-assistant";
    root.setAttribute("aria-label", "Nexis Study Assistant");
    root.innerHTML = `
      <div class="nx-header">
        <div class="nx-brand-wrap">
          <a class="nx-brand" data-nx-link="guns" href="${SOCIAL.guns}" target="_blank" rel="noopener noreferrer" title="Open guns.lol/knowxx001">
            <span class="nx-dot"></span><strong>NEXIS AI</strong>
          </a>
          <small>Study Assistant</small>
        </div>
        <div class="nx-actions">
          <button data-act="min" aria-label="Minimize" title="Minimize">—</button>
          <button data-act="close" aria-label="Close" title="Hide assistant">×</button>
        </div>
      </div>
      <div class="nx-body">
        <div class="nx-status" id="nx-status">Connected to LMS</div>
        <div id="nx-content"></div>
        <div class="nx-social" aria-label="Nexis social links">
          <a href="${SOCIAL.instagram}" target="_blank" rel="noopener noreferrer" title="Instagram" aria-label="Instagram">
            <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="12" r="4.2" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="17.3" cy="6.8" r="1.1" fill="currentColor"/></svg>
          </a>
          <a href="${SOCIAL.discord}" target="_blank" rel="noopener noreferrer" title="Discord" aria-label="Discord">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5.2 6.2A15.2 15.2 0 0 1 9.1 5l.5 1a10.8 10.8 0 0 1 4.8 0l.5-1a15.2 15.2 0 0 1 3.9 1.2c1.1 2.1 1.7 4.5 1.5 7.1-1.5 1.1-3 1.8-4.6 2.2l-1-1.4c.6-.2 1.1-.5 1.6-.8-2.1 1-4.7 1-6.8 0 .5.3 1 .6 1.6.8l-1 1.4c-1.6-.4-3.1-1.1-4.6-2.2-.2-2.6.4-5 1.5-7.1Zm3.8 5.7c.8 0 1.5-.7 1.5-1.6s-.7-1.6-1.5-1.6-1.5.7-1.5 1.6.7 1.6 1.5 1.6Zm6 0c.8 0 1.5-.7 1.5-1.6s-.7-1.6-1.5-1.6-1.5.7-1.5 1.6.7 1.6 1.5 1.6Z" fill="currentColor"/></svg>
          </a>
          <a class="${SOCIAL.github ? "" : "nx-social-disabled"}" href="${SOCIAL.github || "#"}" ${SOCIAL.github ? 'target="_blank" rel="noopener noreferrer"' : ''} title="${SOCIAL.github ? "GitHub" : "GitHub link not configured"}" aria-label="GitHub">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5a9.5 9.5 0 0 0-3 18.5c.5.1.7-.2.7-.5v-1.8c-2.8.6-3.4-1.2-3.4-1.2-.5-1.2-1.1-1.5-1.1-1.5-.9-.6.1-.6.1-.6 1 0 1.5 1 1.5 1 .9 1.5 2.3 1.1 2.9.8.1-.7.4-1.1.7-1.4-2.2-.2-4.5-1.1-4.5-4.8 0-1.1.4-2 .9-2.7-.1-.2-.4-1.3.1-2.7 0 0 .8-.3 2.8 1a9.7 9.7 0 0 1 5.1 0c2-1.3 2.8-1 2.8-1 .5 1.4.2 2.5.1 2.7.6.7.9 1.6.9 2.7 0 3.7-2.3 4.6-4.5 4.8.4.3.7.9.7 1.8v2.7c0 .3.2.6.7.5A9.5 9.5 0 0 0 12 2.5Z" fill="currentColor"/></svg>
          </a>
        </div>
      </div>`;
    document.documentElement.appendChild(root);
    body = root.querySelector(".nx-body");
    header = root.querySelector(".nx-header");
    content = root.querySelector("#nx-content");
    root.addEventListener("click", handle);
    makeDraggable(header);
    closed = false;
  }

  function playBrandSound() {
    try {
      const audio = new Audio(chrome.runtime.getURL("assets/nexis-click.mp3"));
      audio.volume = 0.75;
      audio.play().catch(() => {});
    } catch (_) {}
  }

  function handle(e) {
    const link = e.target.closest("a[data-nx-link]");
    if (link) playBrandSound();
    const b = e.target.closest("button");
    if (!b) return;
    const act = b.dataset.act;
    if (act === "min") {
      minimized = !minimized;
      body.hidden = minimized;
      root.classList.toggle("nx-minimized", minimized);
      b.textContent = minimized ? "+" : "—";
      b.title = minimized ? "Restore" : "Minimize";
    }
    if (act === "close") {
      closed = true;
      root.style.display = "none";
    }
    if (act === "retry") window.dispatchEvent(new CustomEvent("nexis:retry"));
    if (act === "copy") navigator.clipboard?.writeText(b.dataset.text || "");
    if (act === "review") b.textContent = "Marked ✓";
  }

  function reopen() {
    mount();
    closed = false;
    root.style.display = "block";
    if (minimized) {
      body.hidden = true;
      root.classList.add("nx-minimized");
    }
  }

  function setStatus(text, state="") {
    mount(); const s = root.querySelector("#nx-status"); s.textContent = text; s.dataset.state = state;
  }

  function showProcessing(state) {
    mount();
    content.innerHTML = `<div class="nx-processing">
      <div class="nx-spinner"></div><strong>${escapeHtml(state === "ANALYZING" ? "Analyzing question..." : "Detecting question...")}</strong>
      <span>Extracting question</span><span>Generating answer</span><span>Preparing explanation</span></div>`;
  }

  function showAnswer(q, result, showConfidence=true) {
    mount();
    const opts = (q.options || []).map((o, i) => `<li class="nx-option-row ${i === result.answer_index ? "nx-correct-option" : ""}"><span>${i + 1}.</span> ${escapeHtml(o.text)}</li>`).join("");
    const copy = result.explanation || "";
    const concepts = (result.key_concepts || []).map(x => `<li>${escapeHtml(x)}</li>`).join("");
    const answerText = result.answer || (Number.isInteger(result.answer_index) && q.options[result.answer_index] ? q.options[result.answer_index].text : "");
    content.innerHTML = `<div class="nx-question"><span>QUESTION ${q.number ?? "—"}</span><p>${escapeHtml(q.text)}</p></div>
      ${answerText ? `<div class="nx-answer"><label>Correct answer</label><p class="nx-answer-value">${escapeHtml(answerText)}</p></div>` : ""}
      <div class="nx-explain"><label>Study explanation</label><p>${escapeHtml(result.explanation)}</p></div>
      ${concepts ? `<div class="nx-explain"><label>Key concepts</label><ul>${concepts}</ul></div>` : ""}
      ${showConfidence ? `<div class="nx-confidence">Answer confidence: <b>${escapeHtml(result.confidence)}</b></div>` : ""}
      <details open><summary>Detected options (${q.options.length})</summary><ul>${opts}</ul></details>
      <div class="nx-buttons"><button data-act="copy" data-text="${escapeAttr(copy)}">Copy Explanation</button>
      <button data-act="review">Mark for Review</button></div>
      <p class="nx-note">Practice mode: the AI answer is highlighted for your test website.</p>`;
    setStatus("Question analyzed", "ready");
  }

  function highlightCorrectOption(q, result) {
    const index = Number.isInteger(result?.answer_index) ? result.answer_index : -1;
    if (index < 0 || !q?.options?.[index]) return;
    const target = normalize(q.options[index].text);
    document.querySelectorAll("label, [role=radio], [role=checkbox], option").forEach(el => {
      const text = normalize(el.innerText || el.textContent || el.value || "");
      if (text && (text === target || text.includes(target) || target.includes(text))) {
        el.classList.add("nexis-correct-highlight");
        const input = el.control || (el.htmlFor ? document.getElementById(el.htmlFor) : null);
        if (input) input.classList.add("nexis-correct-highlight");
      }
    });
  }

  function normalize(s) { return String(s || "").replace(/\s+/g, " ").trim().toLowerCase(); }
  function showError(message) { mount(); content.innerHTML = `<div class="nx-error"><strong>Unable to continue</strong><p>${escapeHtml(message)}</p><button data-act="retry">Retry</button></div>`; setStatus("Needs attention", "error"); }
  function showCompletion(state) { mount(); content.innerHTML = `<div class="nx-complete"><strong>Session Completed</strong><p>Questions analyzed: ${state.totalProcessed}</p><p>Questions reviewed: ${state.answeredCount}</p><p>Errors: ${state.errors.length}</p></div>`; setStatus("Completed", "done"); }

  function makeDraggable(handle) {
    let drag=false, sx=0, sy=0, ox=0, oy=0;
    handle.addEventListener("pointerdown", e => { if (e.target.closest("button,a")) return; drag=true; handle.setPointerCapture(e.pointerId); const r=root.getBoundingClientRect(); sx=e.clientX; sy=e.clientY; ox=r.left; oy=r.top; });
    handle.addEventListener("pointermove", e => { if(!drag) return; root.style.left = `${Math.max(4, ox + e.clientX-sx)}px`; root.style.top = `${Math.max(4, oy + e.clientY-sy)}px`; root.style.right = "auto"; });
    handle.addEventListener("pointerup", ()=>drag=false);
  }
  function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
  function escapeAttr(s){return escapeHtml(s).replace(/`/g,"&#96;");}
  return { mount, reopen, setStatus, showProcessing, showAnswer, highlightCorrectOption, showError, showCompletion };
})();

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "NEXIS_REOPEN_UI") NexisUI.reopen();
});
