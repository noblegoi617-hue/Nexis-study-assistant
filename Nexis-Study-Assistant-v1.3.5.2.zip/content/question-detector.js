const NexisDetector = (() => {
  const NEXT = /^(next|next question|continue|save\s*&?\s*next|continue\s*→|→)$/i;
  const PREV = /^(previous|prev|back|previous question)$/i;
  const FINISH = /^(finish|submit|complete|end|finalize)$/i;

  function clean(s) { return String(s || "").replace(/\s+/g, " ").trim(); }
  function visible(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect(), st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.visibility !== "hidden" && st.display !== "none";
  }
  function textOf(el) { return clean(el?.innerText || el?.textContent || ""); }

  function controls() {
    return [...document.querySelectorAll("button,input[type=button],input[type=submit],a,[role=button]")]
      .filter(visible).map(el => ({ el, text: clean(el.value || textOf(el)), aria: clean(el.getAttribute("aria-label")) }));
  }

  function findQuestionContainer() {
    const candidates = [
      ...document.querySelectorAll("[role=main],main,form,fieldset,[class*=question i],[id*=question i],[class*=quiz i]")
    ].filter(visible);
    const scored = candidates.map(el => {
      const text = textOf(el);
      const inputs = el.querySelectorAll("input,textarea,select").length;
      const labels = el.querySelectorAll("label").length;
      return { el, score: Math.min(text.length, 1200) / 100 + inputs * 4 + labels * 2 };
    }).sort((a,b) => b.score-a.score);
    return scored[0]?.el || document.body;
  }

  function detect() {
    const container = findQuestionContainer();
    const text = textOf(container);
    if (text.length < 5) return null;

    const options = [];
    const seen = new Set();
    const add = (value, input, label) => {
      const t = clean(value || label);
      if (!t || seen.has(t)) return;
      seen.add(t);
      options.push({ text: t, value: input?.value ?? null, type: input?.type ?? null, selectorHint: input?.id || null });
    };

    container.querySelectorAll("label").forEach(label => {
      const input = label.control || (label.htmlFor ? document.getElementById(label.htmlFor) : null);
      add(textOf(label), input, "");
    });
    container.querySelectorAll("input[type=radio],input[type=checkbox],select option").forEach(input => {
      if (input.tagName === "OPTION") add(textOf(input), null, "");
      else {
        const label = input.id ? container.querySelector(`label[for="${CSS.escape(input.id)}"]`) : null;
        add(input.value, input, textOf(label));
      }
    });

    const qLines = text.split(/\n+/).map(clean).filter(Boolean);
    const questionText = qLines.filter(x => !NEXT.test(x) && !PREV.test(x) && !FINISH.test(x))
      .slice(0, 8).join(" ");
    const numberMatch = text.match(/(?:question|q)\s*#?\s*(\d{1,4})/i);
    let type = options.length ? (options.some(x => x.type === "checkbox") ? "multiple-choice" : "single-choice") : "text";
    if (container.querySelector("textarea")) type = "textarea";
    else if (container.querySelector("select")) type = "dropdown";

    const question = {
      id: clean(container.id || container.getAttribute("data-question-id") || ""),
      number: numberMatch ? Number(numberMatch[1]) : null,
      text: questionText.slice(0, 5000),
      type, options: options.slice(0, 50),
      pageUrl: location.href, timestamp: Date.now()
    };
    // Keep the fingerprint synchronous. This is intentionally a simple
    // deterministic hash because the fingerprint is only used for local
    // duplicate detection; it is NOT a security primitive.
    question.fingerprint = fingerprint(question);
    return question;
  }

  function fingerprint(q) {
    const input = `${q.text}|${q.type}|${q.options.map(o => o.text).join("|")}`;
    let h1 = 0x811c9dc5;
    let h2 = 0x01000193;

    for (let i = 0; i < input.length; i++) {
      const c = input.charCodeAt(i);
      h1 ^= c;
      h1 = Math.imul(h1, 16777619);
      h2 ^= c + i;
      h2 = Math.imul(h2, 2246822519);
    }

    return `${(h1 >>> 0).toString(16).padStart(8, "0")}${(h2 >>> 0).toString(16).padStart(8, "0")}`;
  }

  function findButtons() {
    return controls().map(x => ({
      element: x.el, text: x.text || x.aria,
      kind: NEXT.test(x.text || x.aria) ? "next" : PREV.test(x.text || x.aria) ? "previous" :
            FINISH.test(x.text || x.aria) ? "finish" : "other"
    }));
  }
  return { detect, findButtons, visible };
})();