const NexisNavigation = (() => {
  let last = location.href, timer;
  function start(callback) {
    const fire = () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        if (location.href !== last) {
          last = location.href;
          callback?.(last);
        }
      }, 250);
    };
    const push = history.pushState, replace = history.replaceState;
    history.pushState = function(...a) { const r = push.apply(this,a); fire(); return r; };
    history.replaceState = function(...a) { const r = replace.apply(this,a); fire(); return r; };
    window.addEventListener("popstate", fire);
    window.addEventListener("hashchange", fire);
    return () => {
      window.removeEventListener("popstate", fire);
      window.removeEventListener("hashchange", fire);
    };
  }
  return { start };
})();