const NexisState = (() => {
  let state = {
    sessionId: crypto.randomUUID(), currentQuestion: null, totalProcessed: 0,
    answeredCount: 0, pendingCount: 0, errors: [], startedAt: Date.now(),
    lastUpdated: Date.now(), status: "READY"
  };
  const listeners = new Set();

  async function init() {
    const saved = await chrome.storage.local.get("nexisSession");
    if (saved.nexisSession) state = { ...state, ...saved.nexisSession };
    else await persist();
    return get();
  }
  function get() {
    // State must always remain Chrome-storage/structured-clone safe.
    // Return a plain JSON snapshot so accidental non-cloneable values
    // cannot break the content script.
    return JSON.parse(JSON.stringify(state));
  }
  async function update(patch) {
    state = { ...state, ...patch, lastUpdated: Date.now() };
    await persist();
    listeners.forEach(fn => fn(get()));
    return get();
  }
  async function persist() { await chrome.storage.local.set({ nexisSession: state }); }
  function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); }
  async function reset() {
    state = { sessionId: crypto.randomUUID(), currentQuestion: null, totalProcessed: 0,
      answeredCount: 0, pendingCount: 0, errors: [], startedAt: Date.now(),
      lastUpdated: Date.now(), status: "READY" };
    await persist();
    listeners.forEach(fn => fn(get()));
  }
  return { init, get, update, subscribe, reset };
})();