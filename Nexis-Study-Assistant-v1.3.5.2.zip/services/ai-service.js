const NexisAI = (() => {
  async function getAnswer(question) {
    const cfg = await NexisStorage.getAll();
    const provider = cfg.aiProvider || "gemini";
    const providerName = provider === "openai" ? "OpenAI" : "Gemini";
    if (!cfg.enabled) {
      return { answer: "", explanation: "NEXIS AI is disabled in Settings.", confidence: "Low", reasoning_summary: "Assistant disabled.", key_concepts: [] };
    }

    try {
      // The service worker is the source of truth for the stored key. This avoids
      // a stale content-script configuration showing a false "key not configured" state.
      const response = await chrome.runtime.sendMessage({
        type: "NEXIS_AI_EXPLAIN",
        question: question.text,
        options: (question.options || []).map(o => o.text)
      });
      if (!response?.ok) throw new Error(response?.message || `${providerName} request failed.`);
      return {
        answer: String(response.result?.answer || ""),
        answer_index: Number.isInteger(response.result?.answer_index) ? response.result.answer_index : null,
        explanation: String(response.result?.explanation || "No explanation returned."),
        confidence: response.result?.confidence || "Low",
        reasoning_summary: `Explanation-only response from ${providerName}.`,
        key_concepts: Array.isArray(response.result?.key_concepts) ? response.result.key_concepts : []
      };
    } catch (error) {
      return {
        answer: "",
        answer_index: null,
        explanation: friendlyError(error, providerName),
        confidence: "Low",
        reasoning_summary: `The ${providerName} request could not be completed.`,
        key_concepts: []
      };
    }
  }

  function friendlyError(e, providerName) {
    const msg = String(e?.message || e || `${providerName} request failed.`);
    if (/quota|rate limit|429|high demand|overloaded/i.test(msg)) return `${providerName} is temporarily busy or rate-limited. Try again in a moment.`;
    if (/401|403|api key|permission|unauthorized/i.test(msg)) return `${providerName} rejected the API key. Check that the key is valid and has API access.`;
    if (/404|model/i.test(msg)) return `The selected ${providerName} model was not found or is unavailable to this API key. Try another model in Settings.`;
    return msg;
  }

  return { getAnswer };
})();
