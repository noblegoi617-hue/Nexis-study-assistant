(async()=>{await NexisState.init();const q=document.querySelector("#question"),p=document.querySelector("#processed"),s=document.querySelector("#status");function render(x){q.textContent=x.currentQuestion?.number??"—";p.textContent=x.totalProcessed;s.textContent=x.status.replaceAll("_"," ")}render(NexisState.get());NexisState.subscribe(render);
const cfg=await NexisStorage.getAll();document.querySelector("#enable").textContent=cfg.enabled?"Disable Assistant":"Enable Assistant";
document.querySelector("#enable").onclick=async()=>{await NexisStorage.set({enabled:!cfg.enabled});location.reload()};
document.querySelector("#pause").onclick=async()=>{await NexisState.update({status:"PAUSED"})};
document.querySelector("#show").onclick=async()=>{const tabs=await chrome.tabs.query({active:true,currentWindow:true});if(tabs[0]?.id) chrome.tabs.sendMessage(tabs[0].id,{type:"NEXIS_REOPEN_UI"}).catch(()=>{});};
document.querySelector("#settings").onclick=()=>chrome.runtime.openOptionsPage();
document.querySelector("#clear").onclick=async()=>{await NexisState.reset();render(NexisState.get())};})();