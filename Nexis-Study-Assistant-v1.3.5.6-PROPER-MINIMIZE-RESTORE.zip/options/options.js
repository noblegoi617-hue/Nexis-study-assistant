(async () => {
  const ids = ["aiProvider","apiKey","secondaryApiKey","model","temperature","explanationLength","autoDetect","showConfidence","enabled","providerFallback"];
  const els = Object.fromEntries(ids.map(id => [id, document.getElementById(id)]));
  const cfg = await NexisStorage.getAll();
  for (const id of ids) {
    if (els[id].type === "checkbox") els[id].checked = !!cfg[id];
  }
  els.apiKey.value = cfg.aiProvider === "openai" ? (cfg.openaiApiKey || "") : (cfg.geminiApiKey || "");
  els.secondaryApiKey.value = cfg.aiProvider === "openai" ? (cfg.geminiApiKey || "") : (cfg.openaiApiKey || "");
  els.model.value = cfg.model ?? "";
  els.providerFallback.checked = !!cfg.providerFallback;
  els.temperature.value = cfg.temperature ?? 0.2;
  els.explanationLength.value = cfg.explanationLength ?? "short";

  const result = document.querySelector("#testResult");
  const saved = document.querySelector("#saved");
  const keyLabel = document.querySelector("#keyLabel");

  function updateProviderUI() {
    const openai = els.aiProvider.value === "openai";
    keyLabel.textContent = openai ? "OpenAI API Key" : "Gemini API Key";
    document.getElementById("secondaryKeyLabel").textContent = openai ? "Gemini API Key (optional fallback)" : "OpenAI API Key (optional fallback)";
    els.apiKey.placeholder = openai ? "Paste your OpenAI API key" : "Paste your Gemini API key";
    const options = openai
      ? [["gpt-5.6-luna", "gpt-5.6-luna (OpenAI)"], ["gpt-5.6-terra", "gpt-5.6-terra (OpenAI)"], ["gpt-5.6-sol", "gpt-5.6-sol (OpenAI)"]]
      : [["gemini-2.5-flash-lite", "gemini-2.5-flash-lite (Free Tier)"], ["gemini-3.5-flash-lite", "gemini-3.5-flash-lite"], ["gemini-3.8-flash", "gemini-3.8-flash"], ["gemini-3.5-flash", "gemini-3.5-flash"], ["gemini-3.1-flash-lite", "gemini-3.1-flash-lite"], ["gemini-flash-latest", "gemini-flash-latest"]];
    const current = els.model.value;
    els.model.innerHTML = options.map(([v,t]) => `<option value="${v}">${t}</option>`).join("");
    els.model.value = options.some(([v]) => v === current) ? current : options[0][0];
  }

  els.aiProvider.addEventListener("change", () => {
    const previousProvider = els.aiProvider.dataset.previousProvider || cfg.aiProvider || "gemini";
    if (previousProvider === "gemini") cfg.geminiApiKey = els.apiKey.value.trim();
    else cfg.openaiApiKey = els.apiKey.value.trim();
    const nextProvider = els.aiProvider.value;
    els.apiKey.value = nextProvider === "openai" ? (cfg.openaiApiKey || "") : (cfg.geminiApiKey || "");
    els.secondaryApiKey.value = nextProvider === "openai" ? (cfg.geminiApiKey || "") : (cfg.openaiApiKey || "");
    els.aiProvider.dataset.previousProvider = nextProvider;
    updateProviderUI();
  });
  els.aiProvider.dataset.previousProvider = els.aiProvider.value;
  updateProviderUI();

  document.querySelector("#form").addEventListener("submit", async e => {
    e.preventDefault();
    const provider = els.aiProvider.value;
    const primaryKey = els.apiKey.value.trim();
    const secondaryKey = els.secondaryApiKey.value.trim();
    await NexisStorage.set({
      aiProvider: provider,
      geminiApiKey: provider === "gemini" ? primaryKey : secondaryKey,
      openaiApiKey: provider === "openai" ? primaryKey : secondaryKey,
      apiKey: "",
      apiEndpoint: els.aiProvider.value === "openai" ? "https://api.openai.com/v1" : "https://generativelanguage.googleapis.com/v1beta",
      model: els.model.value.trim(),
      temperature: Number(els.temperature.value || 0.2),
      explanationLength: els.explanationLength.value,
      autoDetect: els.autoDetect.checked,
      showConfidence: els.showConfidence.checked,
      enabled: els.enabled.checked,
      providerFallback: els.providerFallback.checked
    });
    saved.textContent = "Saved";
    result.textContent = "";
    setTimeout(() => saved.textContent = "", 1800);
  });

  document.querySelector("#test").addEventListener("click", async () => {
    result.className = "test-result pending";
    result.textContent = `Testing ${els.aiProvider.value === "openai" ? "OpenAI" : "Gemini"} connection…`;
    const key = els.apiKey.value.trim();
    const model = els.model.value.trim();
    if (!key) {
      result.className = "test-result error";
      result.textContent = `Enter a ${els.aiProvider.value === "openai" ? "OpenAI" : "Gemini"} API key first.`;
      return;
    }
    try {
      const response = await chrome.runtime.sendMessage({ type: "NEXIS_AI_TEST", aiProvider: els.aiProvider.value, apiKey: key, model });
      if (response?.ok) {
        result.className = "test-result success";
        result.textContent = `✓ ${response.message || "Connection successful."}`;
      } else {
        result.className = "test-result error";
        result.textContent = `✕ ${response?.message || "Connection failed."}`;
      }
    } catch (error) {
      result.className = "test-result error";
      result.textContent = `✕ ${error?.message || "Could not contact the extension service worker."}`;
    }
  });
})();
