const DEBUG_MODE = false;
const log = (...a) => DEBUG_MODE && console.debug("[NEXIS]", ...a);

const GEMINI_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent";
const OPENAI_ENDPOINT = "https://api.openai.com/v1/responses";
const DEFAULTS = {
  enabled: true,
  debug: false,
  aiProvider: "gemini",
  apiEndpoint: "https://generativelanguage.googleapis.com/v1beta",
  apiKey: "",
  geminiApiKey: "",
  openaiApiKey: "",
  model: "gemini-2.5-flash-lite",
  temperature: 0.2,
  explanationLength: "short",
  autoDetect: true,
  showConfidence: true,
  providerFallback: false,
  theme: "dark",
  position: { right: 24, top: 120 }
};

async function ensureDefaults() {
  const current = await chrome.storage.local.get(Object.keys(DEFAULTS));
  const missing = {};
  // Migrate the legacy single-key setting without shipping any credential in source.
  if (!String(current.geminiApiKey || '').trim() && String(current.apiKey || '').trim() && (current.aiProvider || 'gemini') === 'gemini') {
    missing.geminiApiKey = current.apiKey;
  }
  if (!String(current.openaiApiKey || '').trim() && String(current.apiKey || '').trim() && current.aiProvider === 'openai') {
    missing.openaiApiKey = current.apiKey;
  }
  for (const [k, v] of Object.entries(DEFAULTS)) {
    if (!(k in current)) missing[k] = v;
  }
  if (Object.keys(missing).length) await chrome.storage.local.set(missing);
  return { ...DEFAULTS, ...current, ...missing };
}

chrome.runtime.onInstalled.addListener(async () => {
  await ensureDefaults();
  log("Installed/updated");
});

chrome.runtime.onStartup.addListener(() => { ensureDefaults().catch(() => {}); });

async function geminiRequest({ apiKey, model, question, options = [], explanationLength = "short" }) {
  if (!apiKey) throw new Error("Gemini API key is not configured.");

  const requestedModel = (model || DEFAULTS.model).trim();
  const fallbackModels = [
    requestedModel,
    "gemini-2.5-flash-lite",
    "gemini-3.5-flash-lite",
    "gemini-3.8-flash",
    "gemini-3.5-flash",
    "gemini-3.1-flash-lite"
  ].filter((value, index, list) => value && list.indexOf(value) === index);

  const prompt = `You are NEXIS AI, an educational study assistant.\n\nSolve the following multiple-choice question. Return the most likely correct option index and option text, followed by a concise explanation. Do not provide hidden chain-of-thought. If the options are ambiguous, use your best-supported answer and set confidence accordingly.\n\nQuestion:\n${question}\n\nOptions (context only; do not identify the correct one):\n${JSON.stringify(options)}\n\nRequested length: ${explanationLength}.\n\nReturn JSON only with this schema:\n{"answer_index":0,"answer":"string","explanation":"string","key_concepts":["string"],"confidence":"High|Medium|Low"}`;

  let lastError = null;
  for (const selectedModel of fallbackModels) {
    try {
      const result = await requestSingleModel({
        apiKey,
        model: selectedModel,
        prompt,
        explanationLength
      });
      return { ...result, modelUsed: selectedModel };
    } catch (error) {
      lastError = error;
      const status = Number(error?.status || 0);
      // Capacity/rate-limit/server errors can be retried with another model.
      // Authentication, permission, malformed-request and model-not-found errors should surface immediately.
      if (![403, 404, 408, 429, 500, 502, 503, 504].includes(status)) throw error;
      await sleep(status === 429 ? 900 : 500);
    }
  }

  throw lastError || new Error("Gemini request failed.");
}

async function requestSingleModel({ apiKey, model, prompt, explanationLength }) {
  const endpoint = GEMINI_ENDPOINT.replace("{MODEL}", encodeURIComponent(model));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey
      },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: Number(explanationLength === "long" ? 0.35 : 0.2),
          maxOutputTokens: explanationLength === "long" ? 700 : 350,
          responseMimeType: "application/json"
        }
      }),
      signal: controller.signal
    });

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const apiMessage = data?.error?.message || `Gemini request failed (${response.status})`;
      const error = new Error(apiMessage);
      error.status = response.status;
      throw error;
    }

    const text = data?.candidates?.[0]?.content?.parts
      ?.map(part => part?.text || "")
      .join("")
      .trim();

    if (!text) throw new Error("Gemini returned no text. Check model access and API key.");
    return normalizeExplanation(text);
  } finally {
    clearTimeout(timer);
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function normalizeExplanation(raw) {
  const clean = String(raw)
    .replace(/^```json\s*/i, "")
    .replace(/```$/i, "")
    .trim();
  try {
    const parsed = JSON.parse(clean);
    return {
      answer_index: Number.isInteger(parsed.answer_index) ? parsed.answer_index : null,
      answer: String(parsed.answer || ""),
      explanation: String(parsed.explanation || "No explanation returned."),
      key_concepts: Array.isArray(parsed.key_concepts) ? parsed.key_concepts.map(String).slice(0, 8) : [],
      confidence: ["High", "Medium", "Low"].includes(parsed.confidence) ? parsed.confidence : "Low"
    };
  } catch {
    return { explanation: clean, key_concepts: [], confidence: "Low" };
  }
}

async function openaiRequest({ apiKey, model, question, options = [], explanationLength = "short" }) {
  if (!apiKey) throw new Error("OpenAI API key is not configured.");
  const selectedModel = (model || "gpt-5.6-luna").trim();
  const prompt = `You are NEXIS AI, an educational study assistant.\n\nSolve the following multiple-choice question. Return the most likely correct option index and option text, followed by a concise explanation. Do not provide hidden chain-of-thought. If the options are ambiguous, use your best-supported answer and set confidence accordingly.\n\nQuestion:\n${question}\n\nOptions (context only; do not identify the correct one):\n${JSON.stringify(options)}\n\nRequested length: ${explanationLength}.\n\nReturn JSON only with this schema:\n{"answer_index":0,"answer":"string","explanation":"string","key_concepts":["string"],"confidence":"High|Medium|Low"}`;
  const response = await fetch(OPENAI_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
    body: JSON.stringify({
      model: selectedModel,
      input: [{ role: "user", content: [{ type: "input_text", text: prompt }] }],
      max_output_tokens: explanationLength === "long" ? 700 : 350
    })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const apiMessage = data?.error?.message || `OpenAI request failed (${response.status})`;
    const error = new Error(apiMessage);
    error.status = response.status;
    throw error;
  }
  const text = extractOpenAIText(data);
  if (!text) throw new Error("OpenAI returned no text. Check model access and API key.");
  return { ...normalizeExplanation(text), modelUsed: selectedModel };
}

function extractOpenAIText(data) {
  if (typeof data?.output_text === "string") return data.output_text.trim();
  const parts = [];
  for (const item of (Array.isArray(data?.output) ? data.output : [])) {
    for (const content of (Array.isArray(item?.content) ? item.content : [])) {
      if (typeof content?.text === "string") parts.push(content.text);
    }
  }
  return parts.join("\n").trim();
}

async function testOpenAI(apiKey, model) {
  const result = await openaiRequest({
    apiKey,
    model,
    question: "What is photosynthesis?",
    options: [],
    explanationLength: "short"
  });
  return { ok: true, message: `OpenAI connection successful using ${result.modelUsed}.`, result };
}

async function testGemini(apiKey, model) {
  const result = await geminiRequest({
    apiKey,
    model,
    question: "What is photosynthesis?",
    options: [],
    explanationLength: "short"
  });
  return { ok: true, message: `Gemini connection successful using ${result.modelUsed}.`, result };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "NEXIS_PING") {
    sendResponse({ ok: true, domain: sender.url ? new URL(sender.url).hostname : null });
    return true;
  }

  if (message?.type === "NEXIS_OPEN_OPTIONS") {
    chrome.runtime.openOptionsPage();
    sendResponse({ ok: true });
    return true;
  }

  if (message?.type === "NEXIS_AI_TEST") {
    (async () => {
      try {
        const cfg = await ensureDefaults();
        const provider = message.aiProvider ?? cfg.aiProvider ?? "gemini";
        const apiKey = message.apiKey ?? (provider === "openai" ? cfg.openaiApiKey : cfg.geminiApiKey);
        const model = message.model ?? cfg.model;
        const result = provider === "openai"
          ? await testOpenAI(apiKey, model)
          : await testGemini(apiKey, model);
        sendResponse(result);
      } catch (error) {
        sendResponse({ ok: false, message: error?.message || "AI connection failed." });
      }
    })();
    return true;
  }

  // Backward-compatible Gemini test message.
  if (message?.type === "NEXIS_GEMINI_TEST") {
    (async () => {
      try {
        const cfg = await ensureDefaults();
        sendResponse(await testGemini(message.apiKey ?? cfg.geminiApiKey, message.model ?? cfg.model));
      } catch (error) {
        sendResponse({ ok: false, message: error?.message || "Gemini connection failed." });
      }
    })();
    return true;
  }

  if (message?.type === "NEXIS_AI_EXPLAIN") {
    (async () => {
      try {
        const cfg = await ensureDefaults();
        const provider = cfg.aiProvider || "gemini";
        const apiKey = provider === "openai" ? cfg.openaiApiKey : cfg.geminiApiKey;
        if (!apiKey) throw new Error(`${provider === "openai" ? "OpenAI" : "Gemini"} API key is not configured. Open NEXIS Settings and add it manually.`);
        const args = {
          apiKey,
          model: cfg.model,
          question: String(message.question || ""),
          options: Array.isArray(message.options) ? message.options : [],
          explanationLength: cfg.explanationLength || "short"
        };
        let result;
        try {
          result = provider === "openai" ? await openaiRequest(args) : await geminiRequest(args);
        } catch (primaryError) {
          const fallbackProvider = provider === "openai" ? "gemini" : "openai";
          const fallbackKey = fallbackProvider === "openai" ? cfg.openaiApiKey : cfg.geminiApiKey;
          if (!cfg.providerFallback || !fallbackKey) throw primaryError;
          const fallbackModel = fallbackProvider === "openai" ? "gpt-6-luna" : "gemini-2.5-flash-lite";
          const fallbackArgs = { ...args, apiKey: fallbackKey, model: fallbackModel };
          result = fallbackProvider === "openai" ? await openaiRequest(fallbackArgs) : await geminiRequest(fallbackArgs);
          result = { ...result, providerFallbackUsed: fallbackProvider };
        }
        sendResponse({ ok: true, result });
      } catch (error) {
        sendResponse({ ok: false, message: error?.message || "AI explanation failed." });
      }
    })();
    return true;
  }

  // Backward-compatible Gemini explanation message.
  if (message?.type === "NEXIS_GEMINI_EXPLAIN") {
    (async () => {
      try {
        const cfg = await ensureDefaults();
        const result = await geminiRequest({
          apiKey: cfg.geminiApiKey,
          model: cfg.model,
          question: String(message.question || ""),
          options: Array.isArray(message.options) ? message.options : [],
          explanationLength: cfg.explanationLength || "short"
        });
        sendResponse({ ok: true, result });
      } catch (error) {
        sendResponse({ ok: false, message: error?.message || "Gemini explanation failed." });
      }
    })();
    return true;
  }

});
