const NexisStorage = (() => {
  const DEFAULTS = {
    enabled: true, debug: false, aiProvider: "gemini", apiEndpoint: "",
    apiKey: "", geminiApiKey: "", openaiApiKey: "", model: "gemini-2.5-flash-lite", temperature: 0.2, explanationLength: "short",
    autoDetect: true, showConfidence: true, providerFallback: false, theme: "dark",
    position: { right: 24, top: 120 }
  };
  async function getAll() { return { ...DEFAULTS, ...(await chrome.storage.local.get(null)) }; }
  async function get(keys) { return chrome.storage.local.get(keys); }
  async function set(values) { return chrome.storage.local.set(values); }
  async function clearSession() { return chrome.storage.local.remove(["nexisSession"]); }
  return { DEFAULTS, getAll, get, set, clearSession };
})();